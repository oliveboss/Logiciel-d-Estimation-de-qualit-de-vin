﻿using Microsoft.EntityFrameworkCore;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using TravailPratique02.Models;
using TravailPratique02.ViewModels;
using MahApps.Metro.IconPacks;

namespace TravailPratique02
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            // Créez les options de contexte pour MonApplicationContext
            var optionsBuilder = new DbContextOptionsBuilder<MonApplicationContext>();
            optionsBuilder.UseSqlServer("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=master;Integrated Security=True;Connect Timeout=30;Encrypt=False;Trust Server Certificate=False;Application Intent=ReadWrite;Multi Subnet Failover=False"); // Remplacez YourConnectionStringHere par votre chaîne de connexion

            // Créez l'instance de GreetingViewModel en passant les options de contexte
            var viewModel = new GreetingViewModel(optionsBuilder.Options);

            // Définissez le ViewModel comme DataContext de la fenêtre
            DataContext = viewModel;

            //private void TogglePasswordVisibility_Click(object sender, RoutedEventArgs e)
            //{
            //    if (TogglePasswordVisibility.IsChecked == true)
            //    {
            //        // Si le bouton est coché, afficher le mot de passe
            //        MotDePasse.Visibility = Visibility.Visible;
            //    }
            //    else
            //    {
            //        // Sinon, masquer le mot de passe
            //        MotDePasse.Visibility = Visibility.Collapsed;
            //    }
            //}
        }
    }
}