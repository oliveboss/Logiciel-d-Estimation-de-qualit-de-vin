﻿using Elfie.Serialization;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using TravailPratique02.Models;
using TravailPratique02.ViewModels;

namespace TravailPratique02
{
    /// <summary>
    /// Logique d'interaction pour Entité.xaml
    /// </summary>
    public partial class Entité : Window
    {
        public Entité()
        {
            InitializeComponent();
            // Créez les options de contexte pour MonApplicationContext
            var optionsBuilder = new DbContextOptionsBuilder<MonApplicationContext>();
            optionsBuilder.UseSqlServer("Data Source = (localdb)\\MSSQLLocalDB; Integrated Security = True; Connect Timeout = 30; Encrypt = True; Trust Server Certificate = False; Application Intent = ReadWrite; Multi Subnet Failover = False"); // Remplacez YourConnectionStringHere par votre chaîne de connexion

            // Créez l'instance de GreetingViewModel en passant les options de contexte
            var viewModel = new GreetingViewModel(optionsBuilder.Options);

            // Définissez le ViewModel comme DataContext de la fenêtre
            DataContext = viewModel;


        }
    }
}
