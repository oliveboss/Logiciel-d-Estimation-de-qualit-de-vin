﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace TravailPratique02.Migrations
{
    /// <inheritdoc />
    public partial class AjoutClient_Vin : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Clients",
                columns: table => new
                {
                    ClientId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Nom = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Prenom = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Clients", x => x.ClientId);
                });

            migrationBuilder.CreateTable(
                name: "Vins",
                columns: table => new
                {
                    VinId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Alcool = table.Column<float>(type: "real", nullable: false),
                    Sulphate = table.Column<float>(type: "real", nullable: false),
                    AcideCitrique = table.Column<float>(type: "real", nullable: false),
                    AcideVolatile = table.Column<float>(type: "real", nullable: false),
                    Qualite = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Vins", x => x.VinId);
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Clients");

            migrationBuilder.DropTable(
                name: "Vins");
        }
    }
}
