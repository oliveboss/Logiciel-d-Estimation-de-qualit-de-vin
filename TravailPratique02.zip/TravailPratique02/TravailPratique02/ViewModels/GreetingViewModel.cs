﻿using CsvHelper.Configuration;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using System;
 using Microsoft.Win32;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel.DataAnnotations;
using CsvHelper;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Security;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using TravailPratique02.Models;
using System.Security.RightsManagement;
using SimpleDecisionTreeLibrary;
using ArbreDeDecision;

namespace TravailPratique02.ViewModels
{
    public  class GreetingViewModel
    {

        public Oenologue user;
      //public Arbre_de_decision arbreDeDecision = new Arbre_de_decision();
        public Models.Greeting Greeting { get; set; }
        // Déclarer une collection pour chaque attribut (Civilité...)
        public ObservableCollection<string> Civilities { get; set; }
        public ICommand RegisterCommand { get; private set; }
        public ICommand ConnexionCommand { get; set; }
        public ICommand AjouterClientCommand { get; private set; }
        public ICommand OuvrirFichierCommand { get; private set; }
        public ICommand BrowseTrainingDataCommand { get; }
        public ICommand BrowseEvaluationDataCommand { get; }
        public ICommand StartTrainingCommand { get; }

        public ICommand grilleDonne { get; set; }
        // Définissez la propriété ListeVins comme une ObservableCollection de votre modèle Vin
        public ObservableCollection<Models.Vin> ListeVins { get; set; }

        public UserProfile utilisateur_connete;
        public ICommand PredictCommand { get; }

        // Ajoutez un champ pour stocker les options de contexte
        private readonly DbContextOptions<MonApplicationContext> _dbContextOptions;

        public GreetingViewModel()
        {
            // Initialisation sans paramètres


        }




        // Modifiez le constructeur pour prendre les options de contexte en paramètre
        public GreetingViewModel(DbContextOptions<MonApplicationContext> dbContextOptions)
        {
            
            _dbContextOptions = dbContextOptions;

            // Initialisez la liste des vins
            ListeVins = new ObservableCollection<Models.Vin>();

            Greeting = new Models.Greeting();
            Civilities = new ObservableCollection<string>() { "Masculin", "Feminin", "Autres" };

            // Initialisation de la commande d'inscription
            RegisterCommand = new RelayCommand(
                canExecute: (parameter) => true,  // Toujours autoriser l'inscription pour l'instant
                execute: (parameter) => Inscrire()); // Appeler la méthode Inscrire lorsque la commande est exécutée

            ConnexionCommand = new RelayCommand(
                canExecute: (parameter) => true,
                execute: (parameter) => SeConnecter());
           
            AjouterClientCommand = new RelayCommand(
                canExecute: (parameter) => true,
                execute: (parameter) => AjouterClient());

            OuvrirFichierCommand = new RelayCommand(
              canExecute: (parameter) => true,
              execute: (parameter) => OuvrirFichier());

            BrowseTrainingDataCommand = new RelayCommand(
              canExecute: (parameter) => true,
              execute: (parameter) => BrowseTrainingData());

            BrowseEvaluationDataCommand = new RelayCommand(
             canExecute: (parameter) => true,
             execute: (parameter) => BrowseEvaluationData());

            StartTrainingCommand = new RelayCommand(
                         canExecute: (parameter) => true,
                         execute: (parameter) => StartTraining());

            PredictCommand = new RelayCommand(
                      canExecute: (parameter) => true,
                      execute: (parameter) => prediction());
           
            grilleDonne = new RelayCommand(
                     canExecute: (parameter) => true,
                     execute: (parameter) => ChargerListeVins());

        
        }

        private void ChargerListeVins()
        {



            // Code pour charger les vins depuis la base de données
            using (var context = new MonApplicationContext(_dbContextOptions))
            {
                // Récupérez les vins depuis la base de données
                var vins = context.Vins.ToList();

                // Ajoutez les vins à ListeVins
                foreach (var vin in vins)
                {
                    // Vérifier si le vinId n'est pas déjà présent dans la liste
                    if (!ListeVins.Any(v => v.VinId == vin.VinId))
                    {
                        // Ajouter le vin à la liste uniquement s'il n'est pas déjà présent
                        ListeVins.Add(vin);
                    }
                    else
                    {
                        // Afficher un message indiquant que la liste des vins prédites est complète
                        MessageBox.Show("La liste des vins prédites est complète.", "Information", MessageBoxButton.OK, MessageBoxImage.Information);
                    }
                }
            }
        }
    

    private void BrowseTrainingData()
        {
            // Code pour parcourir et sélectionner le fichier CSV d'apprentissage
            // Vous pouvez utiliser OpenFileDialog pour cela
            // Exemple :
            var openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Fichiers CSV (*.csv)|*.csv";
            openFileDialog.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
            if (openFileDialog.ShowDialog() == true)
            {
                Greeting.TrainingDataFilePath = openFileDialog.FileName;
            }
        }



        private void prediction()
        {
            try
            {


                List<ArbreDeDecision.Vin> donnees_apprentissage = DataLoader.ChargerDonneesApprentissage(Greeting.TrainingDataFilePath);

                List<ArbreDeDecision.Vin> donnees_test = DataLoader.ChargerDonneesApprentissage(Greeting.EvaluationDataFilePath);
                // Définir les attributs
                List<string> attributs = new List<string> { "Alcool", "Sulfate", "Acide_citrique", "Acidite_volatile", "Qualite" };
                // Effectuer la recherche des meilleurs hyperparamètres

                int bestMaxDepth, bestMinSamplesSplit;
                Entrainement.RechercheHyperparametres(donnees_apprentissage, attributs, out bestMaxDepth, out bestMinSamplesSplit);

                // Entraîner le modèle avec les meilleurs hyperparamètres
                ArbreDeDecision.Arbre_de_decision arbre = Entrainement.EntrainementModele(donnees_apprentissage, attributs, bestMaxDepth, bestMinSamplesSplit);

                ArbreDeDecision.Vin vinAAnalyser = new ArbreDeDecision.Vin();
                vinAAnalyser.Alcool = float.Parse(Greeting.Alcool);
                vinAAnalyser.Sulfate = float.Parse(Greeting.Sulfate);
                vinAAnalyser.Acide_citrique = float.Parse(Greeting.AcideCitrique);
                vinAAnalyser.Acidite_volatile = float.Parse( Greeting.AciditeVolatile);
                // Utiliser le modèle pour prédire la qualité du vin

                int qualitePredite = arbre.Predire(vinAAnalyser);

                // Utilisez ces informations pour créer un nouvel objet Client
                Models.Vin nouveauVin= new Models.Vin();
                {
                    nouveauVin.Alcool = vinAAnalyser.Alcool;
                    nouveauVin.Sulphate = vinAAnalyser.Sulfate;
                    nouveauVin.AcideCitrique =vinAAnalyser.Acide_citrique;
                    nouveauVin.AcideVolatile = vinAAnalyser.Acidite_volatile;
                    nouveauVin.Qualite = qualitePredite;


                };

                // Utilisez le contexte Entity Framework pour ajouter ce nouvel objet Client à la base de données
                using (var context = new MonApplicationContext(_dbContextOptions))
                {
                    context.Vins.Add(nouveauVin);
                    context.SaveChanges();
                }

                MessageBox.Show("Qualité prédite pour le vin : " + arbre.Predire(vinAAnalyser));


            }
            catch (Exception ex)
            {
                // Gérer les erreurs et afficher des messages d'erreur à l'utilisateur
                MessageBox.Show($"Une erreur s'est produite lors  de la  prédiction de la qualité du vin : {ex.Message}", "Erreur", MessageBoxButton.OK, MessageBoxImage.Error);
            
        }
        }
        private void BrowseEvaluationData()
        {
            // Code pour parcourir et sélectionner le fichier CSV d'évaluation
          
            var openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Fichiers CSV (*.csv)|*.csv";
            openFileDialog.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
            if (openFileDialog.ShowDialog() == true)
            {
                Greeting.EvaluationDataFilePath = openFileDialog.FileName;
            }
        }

        public void StartTraining()
        {
            try
            {
                // Créer une instance de l'arbre de décision

                List<ArbreDeDecision.Vin> donnees_apprentissage = DataLoader.ChargerDonneesApprentissage(Greeting.TrainingDataFilePath);

                List<ArbreDeDecision.Vin> donnees_test = DataLoader.ChargerDonneesApprentissage(Greeting.EvaluationDataFilePath);
                // Définir les attributs
                List<string> attributs = new List<string> { "Alcool", "Sulfate", "Acide_citrique", "Acidite_volatile", "Qualite" };
                // Effectuer la recherche des meilleurs hyperparamètres
              
                int bestMaxDepth, bestMinSamplesSplit;
                Entrainement.RechercheHyperparametres(donnees_apprentissage, attributs, out bestMaxDepth, out bestMinSamplesSplit);

                // Entraîner le modèle avec les meilleurs hyperparamètres
                 ArbreDeDecision.Arbre_de_decision arbre = Entrainement.EntrainementModele(donnees_apprentissage, attributs, bestMaxDepth, bestMinSamplesSplit);


                MessageBox.Show("Arbre construit avec succès.", "Succès", MessageBoxButton.OK, MessageBoxImage.Information);

                // Évaluation finale sur l'ensemble de test
                double testSetPrecision = Entrainement.EvaluationFinale(arbre, donnees_test);
                Greeting.AccuracyRate = Performance.EvaluerModele(arbre, donnees_test) * 100;

                Greeting.Taux_confusion =100 -  Performance.EvaluerModele(arbre, donnees_test) * 100;
                




            }
            catch (Exception ex)
            {
                // Gérer les erreurs et afficher des messages d'erreur à l'utilisateur
                MessageBox.Show($"Une erreur s'est produite lors de la construction de l'arbre de décision : {ex.Message}", "Erreur", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }


        // Méthode appelée lors de l'inscription
        private void Inscrire()
        {
            if (Greeting.FieldsFilled)
            {

              

                // Créer un nouvel objet Oenologue à partir des données de l'utilisateur
                Oenologue newOenologue = new Oenologue
                {

                    Nom = Greeting.Name,
                    Prenom = Greeting.FirstName,
                    Email = Greeting.Email,
                    DateNaissance = Greeting.DateOfBirth,
                    VilleResidence = Greeting.ResidenceCity,
                    Civilitie = Greeting.Civilitie ,
                    MotDePasse = Greeting.MotDePasse
                };

                try
                {
                    // Utiliser les options de contexte pour créer une instance de MonApplicationContext
                    using (var context = new MonApplicationContext(_dbContextOptions))
                    {
                        // Vérifier si l'utilisateur avec cet e-mail existe déjà
                        var existingUser = context.Oenologues.FirstOrDefault(u => u.Email == newOenologue.Email);
                        if (existingUser != null)
                        {
                            MessageBox.Show("Un utilisateur avec cet e-mail existe déjà.", "Erreur", MessageBoxButton.OK, MessageBoxImage.Error);
                            return;
                        }

                        // Ajouter le nouvel utilisateur à la base de données
                        context.Oenologues.Add(newOenologue);
                        context.SaveChanges();
                    }

                    MessageBox.Show("Inscription réussie ! Vous pouvez maintenant vous connecter.", "Succès", MessageBoxButton.OK, MessageBoxImage.Information);
                    ClearFields();
                    Greeting.SelectConnexionTab = true;
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Une erreur s'est produite lors de l'inscription : {ex.Message}", "Erreur", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            else
            {
                MessageBox.Show("Veuillez remplir tous les champs obligatoires.", "Erreur", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }


        private void ClearFields()
        {
            Greeting.Name = string.Empty;
            Greeting.FirstName = string.Empty;
            Greeting.Email = string.Empty;
            Greeting.DateOfBirth = null;
            Greeting.ResidenceCity = string.Empty;
            Greeting.Civilitie = null;
            Greeting.MotDePasse=null;
        }

        private void SeConnecter()
        {
            try
            {
                using (var context = new MonApplicationContext(_dbContextOptions))
                {
                    // Recherche de l'utilisateur dans la base de données par son adresse e-mail
                    var existingUser = context.Oenologues.FirstOrDefault(u => u.Email == Greeting.Id_Email);

                    if (existingUser != null)
                    {
                        // Vérification du mot de passe
                        if (existingUser.MotDePasse == Greeting.Password)
                        {
                           
                          
                            // Mot de passe correct, connexion réussie

                            // Affichage d'un message de connexion réussie
                            MessageBox.Show("Connexion réussie !", "Succès", MessageBoxButton.OK, MessageBoxImage.Information);

                            // Affichage de la fenêtre principale
                            MenuPrincipal menuPrincipal = new MenuPrincipal();
                            menuPrincipal.Show();
                            
                            // Charger les informations de l'utilisateur lors de la création de la vue modèle
                            ChargerInformationsUtilisateur();

                            user = GetOenologueByEmail(existingUser.Email);


                            // Fermeture de la fenêtre actuelle
                            Application.Current.MainWindow.Close();
                        }
                        else
                        {
                            // Mot de passe incorrect
                            MessageBox.Show("Mot de passe incorrect.", "Erreur", MessageBoxButton.OK, MessageBoxImage.Error);
                        }
                    }
                    else
                    {
                        // Utilisateur non trouvé
                        MessageBox.Show("Aucun utilisateur trouvé avec cette adresse e-mail.", "Erreur", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
            }
            catch (Exception ex)
            {
                // Gestion des exceptions
                MessageBox.Show($"Une erreur s'est produite lors de la connexion : {ex.Message}", "Erreur", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }


        

// Méthode pour récupérer un Oenologue à partir de la base de données en fonction de son adresse e-mail
 public Oenologue GetOenologueByEmail(string email)
    {
        Oenologue oenologue = null;

        // Créer le contexte Entity Framework pour interagir avec la base de données
        using (var context = new MonApplicationContext(_dbContextOptions))
        {
            // Recherchez l'oenologue en fonction de son adresse e-mail
            oenologue = context.Oenologues.FirstOrDefault(o => o.Email == email);
        }

        return oenologue;
    }

    private void OuvrirFichier()
        {
            try
            {
                // Chemin d'accès au fichier CSV
                //string filePath = @"C:\Users\kemda\OneDrive - UQAR\Hiver 2024\Programmation Orienté Objet 2\Nouveau Dossier\train_reduced.csv";
                string filePath = @"C:\Users\amouz\OneDrive\Bureau\Donnes_D_Apprentissage.csv";

                // Configuration de CsvHelper pour spécifier le délimiteur de colonne
                var csvConfig = new CsvConfiguration(CultureInfo.InvariantCulture)
                {
                    Delimiter = ";", // Délimiteur point-virgule, correspondant à celui dans votre fichier CSV
                    HasHeaderRecord = true, // Indique que le fichier CSV a une ligne d'en-tête
                };


                // Lecture du fichier CSV avec CsvHelper
                using (var reader = new StreamReader(filePath))
                using (var csv = new CsvHelper.CsvReader(reader, csvConfig))
                {
                    // Ignorer la première ligne (en-tête)
                  // csv.Read();

                    // Lecture des enregistrements du fichier CSV et mapping aux objets MyClass
                    var records = csv.GetRecords<MyClass>().ToList();

                    // Traitement des données lues
                    StringBuilder message = new StringBuilder();
                    foreach (var record in records)
                    {
                        // Vous pouvez faire quelque chose avec chaque enregistrement, par exemple :
                        // Ajouter l'enregistrement à une liste
                        // Afficher les valeurs dans la console

                        // Exemple : Ajouter les valeurs de l'enregistrement au message
                        message.AppendLine($"Alcohol: {record.Alcohol}, Sulphates: {record.Sulphates}, Citric Acid: {record.CitricAcid}, Volatile Acidity: {record.VolatileAcidity}, Quality: {record.Quality}");
                    }

                    // Afficher le message dans une MessageBox
                    // Créer et afficher la fenêtre personnalisée
                    var customDataWindow = new CustomDataWindow(message.ToString());
                    customDataWindow.Show();
                }
            }
            catch (CsvHelper.BadDataException bde)
            {
                MessageBox.Show($"Erreur de données dans le fichier CSV : {bde.Message}", "Erreur", MessageBoxButton.OK, MessageBoxImage.Error);
            }

        }

        public void ChargerInformationsUtilisateur()
        {
            try
            {
                using (var context = new MonApplicationContext(_dbContextOptions))
                {
                    // Recherche de l'utilisateur dans la base de données par son adresse e-mail
                    var currentUser = context.Oenologues.FirstOrDefault(u => u.Email == Greeting.Id_Email);

                    if (currentUser != null)
                    {
                        // Mettre à jour les propriétés de Greeting avec les informations de l'utilisateur
                        Greeting.Name = currentUser.Nom;
                        Greeting.FirstName = currentUser.Prenom;
                        Greeting.Email = currentUser.Email;
                        Greeting.DateOfBirth = currentUser.DateNaissance;
                        Greeting.ResidenceCity = currentUser.VilleResidence;
                        Greeting.Civilitie = currentUser.Civilitie;
                        Greeting.MotDePasse = currentUser.MotDePasse;
                       
                    }
                    else
                    {
                        MessageBox.Show("Aucun utilisateur trouvé avec cette adresse e-mail.", "Erreur", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Une erreur s'est produite lors du chargement des informations de l'utilisateur : {ex.Message}", "Erreur", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        //ajout de client 
        private void AjouterClient()
        {
            try
            {
                // Créer une instance de la fenêtre d'ajout de client
                AjoutClientWindow ajoutClientWindow = new AjoutClientWindow();

                // Afficher la fenêtre modale pour l'ajout de client
                bool? result = ajoutClientWindow.ShowDialog();

                // Vérifier si l'utilisateur a confirmé l'ajout (clic sur le bouton "Enregistrer", par exemple)
                if (result == true)
                {
                    // Récupérer les informations saisies par l'utilisateur à partir des propriétés de la fenêtre d'ajout de client
                    string nomClient = ajoutClientWindow.NomClient;
                    string prenomClient = ajoutClientWindow.PrenomClient; // Ajoutez la récupération du prénom si nécessaire
                                                                          // Continuez ainsi pour récupérer les autres informations nécessaires

                    // Utilisez ces informations pour créer un nouvel objet Client
                    Client nouveauClient = new Client
                    {
                        Nom = nomClient,
                        Prenom = prenomClient,
                        // Continuez d'initialiser les autres propriétés du client si nécessaire
                    };

                    // Utilisez le contexte Entity Framework pour ajouter ce nouvel objet Client à la base de données
                    using (var context = new MonApplicationContext(_dbContextOptions))
                    {
                        context.Clients.Add(nouveauClient);
                        context.SaveChanges();
                    }
                    // Afficher un message box indiquant que le client a été enregistré avec succès
                    MessageBox.Show($"Le client {nomClient} {prenomClient} a été enregistré avec succès.", "Succès", MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
            catch (Exception ex)
            {
                // Gérer les exceptions si nécessaire
                MessageBox.Show($"Une erreur s'est produite lors de l'ajout du client : {ex.Message}", "Erreur", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

      

        public List<MyClass> ChargerDonneesCsv(string cheminFichier)
        {
            List<MyClass> donnees = new List<MyClass>();

            try
            {
                // Configuration de CsvHelper pour spécifier le délimiteur de colonne et ignorer la première ligne
                var csvConfig = new CsvConfiguration(CultureInfo.InvariantCulture)
                {
                    Delimiter = ";", // Délimiteur de colonne (ajustez selon le format de votre fichier CSV)
                    HasHeaderRecord = true, // Indique que le fichier CSV a une ligne d'en-tête
                };

                // Lecture du fichier CSV avec CsvHelper
                using (var reader = new StreamReader(cheminFichier))
                using (var csv = new CsvHelper.CsvReader(reader, csvConfig))
                {
                    // Lecture des enregistrements du fichier CSV et mapping aux objets Donnee
                    donnees = csv.GetRecords<MyClass>().ToList();
                }
            }
            catch (CsvHelper.BadDataException bde)
            {
                MessageBox.Show($"Erreur de données dans le fichier CSV : {bde.Message}", "Erreur", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            return donnees;
        }


    }
}