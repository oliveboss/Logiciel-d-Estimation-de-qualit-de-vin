﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TravailPratique02.Models
{
  public class UserProfile
    {
        public string Nom { get; set; }
        public string Prenom { get; set; }
        public string AdresseCouriel { get; set; }
        public DateTime DateNaissance { get; set; }

        public string ville {  get; set; }  
        public string Genre { get; set; }
        public string MotDePasse { get; set; }
    }
}
