﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;

namespace TravailPratique02.Models
{
    internal class MonApplicationContextFactory : IDesignTimeDbContextFactory<MonApplicationContext>
    {
        public MonApplicationContext CreateDbContext(string[] args)
        {
            var connectionString = "Data Source=(localdb)\\MSSQLLocalDB;Integrated Security=True;Connect Timeout=30;Encrypt=True;Trust Server Certificate=False;Application Intent=ReadWrite;Multi Subnet Failover=False";
            var optionsBuilder = new DbContextOptionsBuilder<MonApplicationContext>();
            optionsBuilder.UseSqlServer(connectionString);

            return new MonApplicationContext(optionsBuilder.Options);
        }
    }
}