﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TravailPratique02.Models
{
  public class Vin
    {

        public int VinId { get; set; }
        public float Alcool { get; set; }
        public float Sulphate { get; set; }
        public float AcideCitrique { get; set; }
        public float AcideVolatile { get; set; }
        public int Qualite { get; set; }
    }
}
