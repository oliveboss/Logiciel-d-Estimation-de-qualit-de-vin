﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Security;
using System.Net;
using System.ComponentModel.DataAnnotations;

namespace TravailPratique02.Models
{
    public class Greeting : INotifyPropertyChanged
    {
        private string? _civilitie;
        [Required(ErrorMessage = "Le champ Civilité est requis.")]
        public string? Civilitie
        {
            get { return _civilitie ; }
            set
            {
                if (_civilitie != value)
                {
                    _civilitie = value;
                    ValidateFields();
                    OnPropertyChanged(nameof(Civilitie));
                }
            }
        }

      
        private string _name;
        [Required(ErrorMessage = "Le champ Nom est requis.")]
        public string Name
        {
            get { return _name; }
            set
            {
                if (_name != value)
                {
                    _name = value;
                    ValidateFields();
                   
                    OnPropertyChanged(nameof(Name));
                  
                }
            }
        }

      
        private string _firstName;
          [Required(ErrorMessage = "Le champ Prénom est requis.")]
        public string FirstName
        {
            get { return _firstName; }
            set
            {
                if (_firstName != value)
                {
                    _firstName = value;
                    ValidateFields();
                    OnPropertyChanged(nameof(FirstName));
                }
            }
        }

        private DateTime? _dateOfBirth;
        [Required(ErrorMessage = "Le champ Date de naissance est requis.")]
        public DateTime? DateOfBirth
        {
            get { return _dateOfBirth; }
            set
            {
                if (_dateOfBirth != value)
                {
                    _dateOfBirth = value;
                    ValidateFields();
                    OnPropertyChanged(nameof(DateOfBirth));
                }
            }
        }


        private string _email;
        [Required(ErrorMessage = "Le champ Adresse courriel est requis.")]
        [EmailAddress(ErrorMessage = "Adresse email invalide.")]
      
        public string Email
        {
            get { return _email; }
            set
            {
                if (_email != value)
                {
                    _email = value;
                   
                    OnPropertyChanged(nameof(Email));
                }
            }
        }

        private string _residenceCity;
        [Required(ErrorMessage = "Le champ Ville de résidence est requis.")]
        public string ResidenceCity
        {
            get { return _residenceCity; }
            set
            {
                if (_residenceCity != value)
                {
                    _residenceCity = value;
                    ValidateFields();
                    OnPropertyChanged(nameof(ResidenceCity));
                }
            }
        }

        private string _motDePasse;

        public string MotDePasse
        {
            get { return _motDePasse; }
            set 
            {
                if (_motDePasse != value)
                { 
                    _motDePasse = value;
                    ValidateFields();
                    OnPropertyChanged(nameof(MotDePasse));
                }
                
            }
        }

        private string _id_Email;
        private string _password;

        [Required(ErrorMessage = "Le champ Adresse Courriel est requis.")]
        public string Id_Email
        {
            get { return _id_Email; }
            set
            {
                if (_id_Email != value)
                {
                    _id_Email = value;
                    OnPropertyChanged(nameof(Id_Email));
                }
            }
        }

        [Required(ErrorMessage = "Le champ Mot de passe est requis.")]
        public string Password
        {
            get { return _password; }
            set
            {
                if (_password != value)
                {
                    _password = value;
                    OnPropertyChanged(nameof(Password));
                }
            }
        }
        private double _accuracyRate;
        public double AccuracyRate
        {
            get { return _accuracyRate; }
            set
            {
                _accuracyRate = value;
                OnPropertyChanged(nameof(AccuracyRate));
            }
        }
        private double _taux_confusion;
        public double Taux_confusion        {
            get { return _taux_confusion; }
            set
            {
                _taux_confusion = value;
                OnPropertyChanged(nameof(Taux_confusion));
            }
        }


        /// Méthode pour convertir un SecureString en string (si nécessaire)

        private string _trainingDataFilePath;
        public string TrainingDataFilePath
        {
            get { return _trainingDataFilePath; }
            set
            {
                _trainingDataFilePath = value;
                OnPropertyChanged(nameof(TrainingDataFilePath));
            }
        }

        private string _evaluationDataFilePath;
        public string EvaluationDataFilePath
        {
            get { return _evaluationDataFilePath; }
            set
            {
                _evaluationDataFilePath = value;
                OnPropertyChanged(nameof(EvaluationDataFilePath));
            }
        }


        // Ajoutez d'autres propriétés de champs de la même manière...

        private bool _fieldsFilled;
        public bool FieldsFilled
        {
            get { return _fieldsFilled; }
            set
            {
                if (_fieldsFilled != value)
                {
                    _fieldsFilled = value;
                    OnPropertyChanged(nameof(FieldsFilled));
                }
            }
        }
        private bool _selectConnexionTab;
        public bool SelectConnexionTab
        {
            get { return _selectConnexionTab; }
            set
            {
                _selectConnexionTab = value;
                OnPropertyChanged(nameof(SelectConnexionTab));
            }
        }

        private string _alcool;
        public string Alcool
        {
            get { return _alcool; }
            set
            {
                if (value != _alcool)
                {
                    _alcool = value;
                    OnPropertyChanged(nameof(Alcool));
                }
            }
        }

        private string _sulfate;
        public string Sulfate
        {
            get { return _sulfate; }
            set
            {
                if (value != _sulfate)
                {
                    _sulfate = value;
                    OnPropertyChanged(nameof(Sulfate));
                }
            }
        }

        private string _acideCitrique;
        public string AcideCitrique
        {
            get { return _acideCitrique; }
            set
            {
                if (value != _acideCitrique)
                {
                    _acideCitrique = value;
                    OnPropertyChanged(nameof(AcideCitrique));
                }
            }
        }

        private string _aciditeVolatile;
        public string AciditeVolatile
        {
            get { return _aciditeVolatile; }
            set
            {
                if (value != _aciditeVolatile)
                {
                    _aciditeVolatile = value;
                    OnPropertyChanged(nameof(AciditeVolatile));
                }
            }
        }


        private void ValidateFields()
        {
            // Vérifiez ici si tous les champs requis sont remplis
            FieldsFilled = !string.IsNullOrWhiteSpace(Name)
                       && !string.IsNullOrWhiteSpace(FirstName)
                        && !string.IsNullOrWhiteSpace(Email)
                        && DateOfBirth != default(DateTime) // Assurez-vous de remplir une date de naissance valide
                        && !string.IsNullOrWhiteSpace(ResidenceCity)
                        && !string.IsNullOrWhiteSpace(Civilitie)
                        && !string.IsNullOrWhiteSpace(MotDePasse);


        }










        public event PropertyChangedEventHandler? PropertyChanged;
    
        private void OnPropertyChanged([CallerMemberName] string propertyName = "")
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    
    }
}
