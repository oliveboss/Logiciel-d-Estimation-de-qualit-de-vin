﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TravailPratique02.Models
{
    public class Client
    {

        public int ClientId { get; set; }
        public string Nom { get; set; }
        public string Prenom { get; set; }
    }
}
