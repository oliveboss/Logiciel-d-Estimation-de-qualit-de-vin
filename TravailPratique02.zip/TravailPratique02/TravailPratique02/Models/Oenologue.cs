﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TravailPratique02.Models
{
    public class Oenologue
    {
        public string Nom { get; set; }
        public string Prenom { get; set; }
        public string Email { get; set; }
        public DateTime? DateNaissance { get; set; }
        public string VilleResidence { get; set; }
        public string Civilitie { get; set; }
        public string MotDePasse { get; set; }
    }
}
