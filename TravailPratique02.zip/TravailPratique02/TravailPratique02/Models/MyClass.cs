﻿using CsvHelper.Configuration.Attributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TravailPratique02.Models
{
    public class MyClass
    {
        [Name("alcohol")] // Indique que cette propriété correspond à la colonne "Alcohol" dans le fichier CSV
        public float Alcohol { get; set; }

        [Name("sulphates")]
        public float Sulphates { get; set; }

        [Name("citric acid")]
        public float CitricAcid { get; set; }

        [Name("volatile acidity")]
        public float VolatileAcidity { get; set; }

        [Name("quality")]
        public int Quality { get; set; }
    }

}