﻿using System;
using Microsoft.EntityFrameworkCore;

namespace TravailPratique02.Models
{
    public class MonApplicationContext : DbContext
    {
        public DbSet<Oenologue> Oenologues { get; set; }
        public DbSet<Vin> Vins { get; set; }
        public DbSet<Client> Clients { get; set; }

        public MonApplicationContext(DbContextOptions<MonApplicationContext> options) : base(options)
        {
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            // Assurez-vous de sécuriser votre chaîne de connexion, surtout dans un environnement de production
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer("Data Source=(localdb)\\MSSQLLocalDB;Integrated Security=True;Connect Timeout=30;Encrypt=True;Trust Server Certificate=False;Application Intent=ReadWrite;Multi Subnet Failover=False");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // Clé primaire
            modelBuilder.Entity<Oenologue>()
                .HasKey(o => o.Email);

            // Autres configurations, comme des relations ou des validations
            modelBuilder.Entity<Oenologue>()
                .Property(o => o.Email)
                .IsRequired()
                .HasMaxLength(255);

            // Vous pouvez ajouter ici d'autres configurations pour d'autres entités
            // Configurations pour l'entité Vin
            modelBuilder.Entity<Vin>()
                .HasKey(v => v.VinId);
            // Ajoute d'autres configurations pour l'entité Vin selon tes besoins

            // Configurations pour l'entité Client
            modelBuilder.Entity<Client>()
                .HasKey(c => c.ClientId);
            // Ajoute d'autres configurations pour l'entité Client selon tes beso
        }
    }
}
