﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace TravailPratique02
{
    /// <summary>
    /// Logique d'interaction pour AjoutClientWindow.xaml
    /// </summary>
    public partial class AjoutClientWindow : Window
    {
     
            public string NomClient { get { return txtNomClient.Text; } }
        public string PrenomClient { get { return txtPrenomClient.Text; } }
            public AjoutClientWindow()
        {
            InitializeComponent();
        }
        private void Enregistrer_Click(object sender, RoutedEventArgs e)
        {
            // Fermer la fenêtre avec un résultat true pour indiquer que l'ajout a été confirmé
            DialogResult = true;
        }
    }
}
